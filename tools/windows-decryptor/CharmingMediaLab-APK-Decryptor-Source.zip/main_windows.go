//go:build windows

package main

import (
	"fmt"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"unicode/utf16"
	"unsafe"
)

const (
	WS_OVERLAPPED      = 0x00000000
	WS_CAPTION         = 0x00C00000
	WS_SYSMENU         = 0x00080000
	WS_MINIMIZEBOX     = 0x00020000
	WS_VISIBLE         = 0x10000000
	WS_CHILD           = 0x40000000
	WS_TABSTOP         = 0x00010000
	WS_BORDER          = 0x00800000
	WS_VSCROLL         = 0x00200000
	WS_EX_CLIENTEDGE   = 0x00000200
	ES_AUTOHSCROLL     = 0x0080
	ES_PASSWORD        = 0x0020
	CBS_DROPDOWNLIST   = 0x0003
	WS_GROUP           = 0x00020000
	WM_DESTROY         = 0x0002
	WM_CLOSE           = 0x0010
	WM_COMMAND         = 0x0111
	WM_SETFONT         = 0x0030
	WM_APP             = 0x8000
	CB_ADDSTRING       = 0x0143
	CB_GETCURSEL       = 0x0147
	CB_SETCURSEL       = 0x014E
	MB_OK              = 0x0
	MB_ICONERROR       = 0x10
	MB_ICONINFORMATION = 0x40
	OFN_FILEMUSTEXIST  = 0x00001000
	OFN_PATHMUSTEXIST  = 0x00000800
	OFN_NOCHANGEDIR    = 0x00000008
	OFN_EXPLORER       = 0x00080000
	IDC_ZIP            = 1101
	IDC_KEY            = 1102
	IDC_OUTPUT         = 1103
	IDC_FORMAT         = 1104
	IDC_PASSWORD       = 1105
	IDC_CONFIRM        = 1106
	IDC_BROWSE_ZIP     = 1201
	IDC_BROWSE_KEY     = 1202
	IDC_BROWSE_OUTPUT  = 1203
	IDC_DECRYPT        = 1204
	IDC_PROTECT        = 1205
	MSG_DONE           = WM_APP + 1
)

var (
	dllUser                                                                                   = syscall.NewLazyDLL("user32.dll")
	dllKernel                                                                                 = syscall.NewLazyDLL("kernel32.dll")
	dllComdlg                                                                                 = syscall.NewLazyDLL("comdlg32.dll")
	regClass                                                                                  = dllUser.NewProc("RegisterClassW")
	createWnd                                                                                 = dllUser.NewProc("CreateWindowExW")
	defProc                                                                                   = dllUser.NewProc("DefWindowProcW")
	sendMsg                                                                                   = dllUser.NewProc("SendMessageW")
	postMsg                                                                                   = dllUser.NewProc("PostMessageW")
	setText                                                                                   = dllUser.NewProc("SetWindowTextW")
	getText                                                                                   = dllUser.NewProc("GetWindowTextW")
	showWnd                                                                                   = dllUser.NewProc("ShowWindow")
	updateWnd                                                                                 = dllUser.NewProc("UpdateWindow")
	getMsg                                                                                    = dllUser.NewProc("GetMessageW")
	translateMsg                                                                              = dllUser.NewProc("TranslateMessage")
	dispatchMsg                                                                               = dllUser.NewProc("DispatchMessageW")
	destroyWnd                                                                                = dllUser.NewProc("DestroyWindow")
	postQuit                                                                                  = dllUser.NewProc("PostQuitMessage")
	enableWnd                                                                                 = dllUser.NewProc("EnableWindow")
	messageBox                                                                                = dllUser.NewProc("MessageBoxW")
	loadCursor                                                                                = dllUser.NewProc("LoadCursorW")
	createFont                                                                                = dllUser.NewProc("CreateFontW")
	getModule                                                                                 = dllKernel.NewProc("GetModuleHandleW")
	getOpenName                                                                               = dllComdlg.NewProc("GetOpenFileNameW")
	getSaveName                                                                               = dllComdlg.NewProc("GetSaveFileNameW")
	hwndMain, hwndZIP, hwndKey, hwndOutput, hwndFormat, hwndPassword, hwndConfirm, hwndStatus uintptr
	hwndDecrypt, hwndProtect                                                                  uintptr
	uiFont, instance                                                                          uintptr
	busy                                                                                      bool
	resultLock                                                                                sync.Mutex
	resultText                                                                                string
	resultOK                                                                                  bool
)

type winClass struct {
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
}
type winPoint struct{ X, Y int32 }
type winMsg struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             winPoint
	Private        uint32
}
type openFileName struct {
	Size         uint32
	Owner        uintptr
	Instance     uintptr
	Filter       *uint16
	CustomFilter *uint16
	MaxCustom    uint32
	FilterIndex  uint32
	File         *uint16
	MaxFile      uint32
	FileTitle    *uint16
	MaxFileTitle uint32
	InitialDir   *uint16
	Title        *uint16
	Flags        uint32
	Offset       uint16
	Extension    uint16
	DefaultExt   *uint16
	CustomData   uintptr
	Hook         uintptr
	TemplateName *uint16
	Reserved     uintptr
	ReservedInt  uint32
	FlagsEx      uint32
}

func w(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func u(s string) uintptr { return uintptr(unsafe.Pointer(w(s))) }
func send(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	r, _, _ := sendMsg.Call(hwnd, uintptr(msg), wp, lp)
	return r
}
func textOf(hwnd uintptr) string {
	buf := make([]uint16, 32768)
	getText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf)
}
func set(hwnd uintptr, s string)              { setText.Call(hwnd, u(s)) }
func message(title, msg string, kind uintptr) { messageBox.Call(hwndMain, u(msg), u(title), kind) }
func control(cls, caption string, style, ex uintptr, x, y, width, height, id int) uintptr {
	h, _, _ := createWnd.Call(ex, u(cls), u(caption), style|WS_CHILD|WS_VISIBLE, uintptr(x), uintptr(y), uintptr(width), uintptr(height), hwndMain, uintptr(id), instance, 0)
	if h != 0 && uiFont != 0 {
		send(h, WM_SETFONT, uiFont, 1)
	}
	return h
}
func label(s string, x, y, width int) { control("STATIC", s, 0, 0, x, y, width, 20, 0) }
func edit(x, y, width int, secret bool) uintptr {
	st := uintptr(WS_TABSTOP | ES_AUTOHSCROLL)
	if secret {
		st |= ES_PASSWORD
	}
	return control("EDIT", "", st, WS_EX_CLIENTEDGE, x, y, width, 25, 0)
}
func button(s string, x, y, width, id int) uintptr {
	return control("BUTTON", s, WS_TABSTOP, 0, x, y, width, 29, id)
}
func chooseFile(title, filter, initial string, save bool) string {
	var buf [32768]uint16
	if initial != "" {
		a := utf16.Encode([]rune(initial))
		if len(a) < len(buf) {
			copy(buf[:], a)
		}
	}
	filters := utf16.Encode([]rune(filter + "\x00"))
	ofn := openFileName{Size: uint32(unsafe.Sizeof(openFileName{})), Owner: hwndMain, Filter: &filters[0], File: &buf[0], MaxFile: uint32(len(buf)), Title: w(title), Flags: OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR}
	var r uintptr
	if save {
		r, _, _ = getSaveName.Call(uintptr(unsafe.Pointer(&ofn)))
	} else {
		ofn.Flags |= OFN_FILEMUSTEXIST
		r, _, _ = getOpenName.Call(uintptr(unsafe.Pointer(&ofn)))
	}
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:])
}
func formatSelection() string {
	idx := int(send(hwndFormat, CB_GETCURSEL, 0, 0))
	switch idx {
	case 1:
		return "pkcs8"
	case 2:
		return "pkcs1"
	case 3:
		return "encrypted"
	default:
		return "auto"
	}
}
func setBusy(value bool) {
	busy = value
	flag := uintptr(1)
	if value {
		flag = 0
	}
	enableWnd.Call(hwndDecrypt, flag)
	enableWnd.Call(hwndProtect, flag)
	enableWnd.Call(hwndFormat, flag)
}
func finish(ok bool, msg string) {
	resultLock.Lock()
	resultText = msg
	resultOK = ok
	resultLock.Unlock()
	postMsg.Call(hwndMain, MSG_DONE, 0, 0)
}
func workDecrypt() {
	if busy {
		return
	}
	zipPath := strings.TrimSpace(textOf(hwndZIP))
	keyPath := strings.TrimSpace(textOf(hwndKey))
	output := strings.TrimSpace(textOf(hwndOutput))
	if zipPath == "" || output == "" {
		message("Missing file", "Select a GitHub ZIP and where to save the APK.", MB_ICONERROR)
		return
	}
	setBusy(true)
	set(hwndStatus, "Decrypting and validating your APK... please keep this window open.")
	password := textOf(hwndPassword)
	format := formatSelection()
	go func() {
		digest, err := decryptGitHubArtifact(zipPath, keyPath, password, format, output)
		if err != nil {
			finish(false, err.Error())
			return
		}
		finish(true, "APK successfully extracted!\r\n\r\n"+output+"\r\n\r\nSHA-256: "+digest+"\r\n\r\nAPK structure checked. Signature verification requires Android apksigner.")
	}()
}
func workProtect() {
	if busy {
		return
	}
	input := strings.TrimSpace(textOf(hwndKey))
	password := textOf(hwndPassword)
	confirm := textOf(hwndConfirm)
	if input == "" {
		message("Missing key", "Choose your unencrypted private PEM key first.", MB_ICONERROR)
		return
	}
	if password != confirm {
		message("Passwords differ", "The password and confirmation do not match.", MB_ICONERROR)
		return
	}
	if len(password) < 12 {
		message("Password too short", "Use at least 12 characters to protect your private key.", MB_ICONERROR)
		return
	}
	output := chooseFile("Save encrypted PEM key", "Encrypted PEM (*.pem)\x00*.pem\x00All files (*.*)\x00*.*\x00", strings.TrimSuffix(input, filepath.Ext(input))+"-Encrypted.pem", true)
	if output == "" {
		return
	}
	if !strings.EqualFold(filepath.Ext(output), ".pem") {
		output += ".pem"
	}
	setBusy(true)
	set(hwndStatus, "Encrypting private key with a password (PBES2 / AES-256-CBC)...")
	go func() {
		err := protectPEM(input, output, password)
		if err != nil {
			finish(false, err.Error())
			return
		}
		finish(true, "Protected PEM key created:\r\n"+output+"\r\n\r\nYour original PEM was left unchanged. This key can decrypt the same builds as before. Keep your password safe.")
	}()
}
func wndProc(hwnd uintptr, msgCode uint32, wp, lp uintptr) uintptr {
	switch msgCode {
	case WM_COMMAND:
		switch uint16(wp & 0xffff) {
		case IDC_BROWSE_ZIP:
			path := chooseFile("Select downloaded GitHub Actions ZIP", "ZIP archives (*.zip)\x00*.zip\x00All files (*.*)\x00*.*\x00", "", false)
			if path != "" {
				set(hwndZIP, path)
				set(hwndOutput, filepath.Join(filepath.Dir(path), "CharmingMediaLab-Sideload.apk"))
			}
		case IDC_BROWSE_KEY:
			path := chooseFile("Select your RSA private PEM", "PEM keys (*.pem;*.txt)\x00*.pem;*.txt\x00All files (*.*)\x00*.*\x00", "", false)
			if path != "" {
				set(hwndKey, path)
			}
		case IDC_BROWSE_OUTPUT:
			path := chooseFile("Save sideload APK as", "Android APK (*.apk)\x00*.apk\x00All files (*.*)\x00*.*\x00", textOf(hwndOutput), true)
			if path != "" {
				if !strings.EqualFold(filepath.Ext(path), ".apk") {
					path += ".apk"
				}
				set(hwndOutput, path)
			}
		case IDC_DECRYPT:
			workDecrypt()
		case IDC_PROTECT:
			workProtect()
		}
		return 0
	case MSG_DONE:
		resultLock.Lock()
		msg := resultText
		ok := resultOK
		resultLock.Unlock()
		setBusy(false)
		if ok {
			set(hwndStatus, "Completed successfully.")
			message("Charming MediaLab", msg, MB_ICONINFORMATION)
		} else {
			set(hwndStatus, "Failed: "+msg)
			message("Cannot complete operation", msg, MB_ICONERROR)
		}
		return 0
	case WM_CLOSE:
		if busy {
			message("Operation running", "Please let the current operation finish before closing.", MB_ICONINFORMATION)
			return 0
		}
		destroyWnd.Call(hwnd)
		return 0
	case WM_DESTROY:
		postQuit.Call(0)
		return 0
	}
	r, _, _ := defProc.Call(hwnd, uintptr(msgCode), wp, lp)
	return r
}
func main() {
	instance, _, _ = getModule.Call(0)
	cursor, _, _ := loadCursor.Call(0, 32512)
	className := w("CharmingMediaLabAPKDecryptorWindow")
	wc := winClass{WndProc: syscall.NewCallback(wndProc), Instance: instance, Cursor: cursor, Background: uintptr(16), ClassName: className}
	r, _, err := regClass.Call(uintptr(unsafe.Pointer(&wc)))
	if r == 0 {
		panic(fmt.Sprintf("RegisterClassW: %v", err))
	}
	fontHeight := int32(-17)
	uiFont, _, _ = createFont.Call(uintptr(uint32(fontHeight)), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 0, 0, u("Segoe UI"))
	hwndMain, _, err = createWnd.Call(0, uintptr(unsafe.Pointer(className)), u("Charming MediaLab - APK Decryptor"), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX, 150, 100, 715, 517, 0, 0, instance, 0)
	if hwndMain == 0 {
		panic(fmt.Sprintf("CreateWindowExW: %v", err))
	}
	label("CHARMING MEDIALAB  |  APK DECRYPTOR", 22, 17, 650)
	label("1. Downloaded GitHub Actions ZIP", 22, 54, 440)
	hwndZIP = edit(22, 78, 545, false)
	button("Browse ZIP...", 579, 76, 108, IDC_BROWSE_ZIP)
	label("2. RSA private key (.pem or .txt)", 22, 119, 470)
	hwndKey = edit(22, 143, 545, false)
	button("Browse Key...", 579, 141, 108, IDC_BROWSE_KEY)
	label("3. Private key type", 22, 184, 300)
	hwndFormat = control("COMBOBOX", "", WS_TABSTOP|CBS_DROPDOWNLIST|WS_VSCROLL, 0, 22, 206, 355, 180, IDC_FORMAT)
	for _, s := range []string{"Auto detect from PEM header (recommended)", "PKCS#8  -  BEGIN PRIVATE KEY", "PKCS#1  -  BEGIN RSA PRIVATE KEY", "Encrypted PKCS#8  -  BEGIN ENCRYPTED PRIVATE KEY"} {
		send(hwndFormat, CB_ADDSTRING, 0, u(s))
	}
	send(hwndFormat, CB_SETCURSEL, 0, 0)
	label("Key password (if encrypted)", 400, 184, 260)
	hwndPassword = edit(400, 206, 287, true)
	label("4. Save finished APK to", 22, 250, 475)
	hwndOutput = edit(22, 273, 545, false)
	button("Save As...", 579, 271, 108, IDC_BROWSE_OUTPUT)
	label("Confirm password (only when creating a protected PEM)", 22, 314, 610)
	hwndConfirm = edit(22, 336, 665, true)
	hwndDecrypt = button("Decrypt && Create APK", 22, 381, 322, IDC_DECRYPT)
	hwndProtect = button("Protect Private Key (.pem)", 365, 381, 322, IDC_PROTECT)
	hwndStatus = control("STATIC", "Ready. Files and passwords stay on this computer.", 0, 0, 22, 432, 665, 35, 0)
	showWnd.Call(hwndMain, 5)
	updateWnd.Call(hwndMain)
	var msg winMsg
	for {
		r, _, _ := getMsg.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		translateMsg.Call(uintptr(unsafe.Pointer(&msg)))
		dispatchMsg.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
