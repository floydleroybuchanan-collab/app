# Charming MediaLab APK Decryptor — Windows 11

A portable native Windows desktop application to open Charming MediaLab GitHub Actions encrypted build downloads and recover the original **already-signed** Android APK.

## Quick start

1. Download `CharmingMediaLab-APK-Decryptor.exe` to your Windows 11 PC.
2. Double-click the EXE to open the GUI. No Python, Java, Node.js, Android Studio, or installer is required.
3. Click **Browse ZIP** and select the complete ZIP downloaded from your GitHub Actions build artifact.
4. Click **Browse Key** and choose your matching RSA private `.pem` (or `.txt` containing a PEM key).
5. Leave **Private key type** on **Auto detect** or manually select your format:
   - `BEGIN PRIVATE KEY` — unencrypted PKCS#8 private key.
   - `BEGIN RSA PRIVATE KEY` — unencrypted RSA PKCS#1 private key.
   - `BEGIN ENCRYPTED PRIVATE KEY` — password-protected PKCS#8 key. Enter its password in **Key password**.
6. Choose an output `.apk` path using **Save As**. An existing APK will **not** be overwritten.
7. Click **Decrypt & Create APK**.

The tool expects `sideload.zip.enc` and `sideload.zip.enc.json` in the downloaded Actions ZIP. It also supports legacy ZIPs with a directly included APK. The decrypted inner ZIP must contain exactly one APK.

## Protect your existing private key with a password

This does NOT create a new RSA key pair or change which GitHub builds your key can unlock:

1. Select your existing **unencrypted** RSA `.pem` or `.txt` with **Browse Key**.
2. Enter a new **12+ character** password into **Key password** and repeat it in **Confirm password**.
3. Click **Protect Private Key (.pem)**.
4. Save it as a **different filename** (for example, `CharmingMediaLab-Private-Encrypted.pem`).
5. To use the new encrypted key later, select it and enter the password. **Auto detect** understands the `BEGIN ENCRYPTED PRIVATE KEY` header.

The encrypted PEM uses the interoperable **PKCS#8 PBES2 / PBKDF2-HMAC-SHA256 (200,000 iterations) / AES-256-CBC** format. Import of encrypted PEMs supports PBES2/PBKDF2 with AES-128/192/256-CBC and HMAC-SHA1/SHA256/SHA384/SHA512. Different encrypted PKCS#8 algorithms are not supported; they produce a clear error.

Keep an offline backup of the original private key before relying on a password-protected copy. **Without the correct original private key (or its mathematically identical encrypted copy), decryption is not possible.**

## Important checks and limitations

- Decryption matches the checked-in `ci/protect-sideload-artifact.mjs` method: **RSA-OAEP-SHA256**, **AES-256-GCM**, and exact JSON authenticated-data fields.
- The tool verifies GCM authentication, parses the decrypted ZIP, checks an included `SHA256SUMS.txt` if present, and checks that the resulting APK contains `AndroidManifest.xml` and `classes.dex`.
- **It does not independently verify the APK's Android signing certificate.** The GitHub workflow is responsible for making a correctly signed APK. If necessary, use the Android SDK's `apksigner verify --verbose --print-certs <file.apk>`.
- If you get **"private key does not match the public key"**, a rename or conversion will not fix it. The GitHub public key used at encryption must match this private key.
- The tool does not repair broken APKs or sign unsigned APKs. It only recovers an APK successfully built and packaged by GitHub Actions.
- Private keys, passwords, decrypted intermediate ZIPs, and provider credentials are **not uploaded** and are not written to application logs. The resulting APK is saved only where you select. Key/password material can be held temporarily in application memory during processing.
- Because authenticated decryption operates in memory, large encrypted artifacts require substantial free RAM.
- This executable has **not been code-signed** with a Windows publisher certificate, and it has been **cross-compiled**, not run under Windows in this environment. Windows SmartScreen may identify it as an unknown publisher. Inspect the source and scan it before running if your Windows security software raises a warning.

## Source / build

Pure Go standard library; native Win32 controls. No external Go dependencies.

To build on Windows with Go 1.23+ installed:

```powershell
$env:CGO_ENABLED='0'
go build -trimpath -ldflags='-H=windowsgui -s -w' -o CharmingMediaLab-APK-Decryptor.exe .
```

Linux cross-compilation:

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags='-H=windowsgui -s -w' -o CharmingMediaLab-APK-Decryptor.exe .
```

Test decryption/key formats with `go test ./...`.
