package main

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestOpenSSLInteroperability(t *testing.T) {
	if _, err := exec.LookPath("openssl"); err != nil {
		t.Skip("OpenSSL not available")
	}
	k, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	der, _ := x509.MarshalPKCS8PrivateKey(k)
	orig := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: der})
	temp := t.TempDir()
	a := filepath.Join(temp, "original.pem")
	b := filepath.Join(temp, "generated-enc.pem")
	c := filepath.Join(temp, "openssl-enc.pem")
	os.WriteFile(a, orig, 0600)
	own, err := encryptPrivateKeyPEM(orig, "test passphrase 1234567!")
	if err != nil {
		t.Fatal(err)
	}
	os.WriteFile(b, own, 0600)
	cmd := exec.Command("openssl", "pkey", "-in", b, "-passin", "pass:test passphrase 1234567!", "-pubout")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("OpenSSL could not read encrypted PEM: %v (%s)", err, out)
	}
	if !bytes.Contains(out, []byte("BEGIN PUBLIC KEY")) {
		t.Fatalf("OpenSSL output unexpected: %s", out)
	}
	cmd = exec.Command("openssl", "pkcs8", "-topk8", "-in", a, "-out", c, "-v2", "aes-256-cbc", "-v2prf", "hmacWithSHA256", "-iter", "200000", "-passout", "pass:test passphrase 1234567!")
	out, err = cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("OpenSSL creation failed: %v (%s)", err, out)
	}
	external, err := os.ReadFile(c)
	if err != nil {
		t.Fatal(err)
	}
	recovered, _, err := parseRSAKey(external, "encrypted", "test passphrase 1234567!")
	if err != nil {
		t.Fatalf("could not decrypt OpenSSL-created PKCS#8: %v", err)
	}
	if recovered.N.Cmp(k.N) != 0 {
		t.Fatal("OpenSSL private key mismatch")
	}
}
