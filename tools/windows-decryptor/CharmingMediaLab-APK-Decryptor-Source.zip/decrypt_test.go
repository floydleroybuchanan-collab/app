package main

import (
	"archive/zip"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func makeZIP(t *testing.T, parts map[string][]byte) []byte {
	t.Helper()
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	for n, data := range parts {
		f, err := zw.Create(n)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = f.Write(data); err != nil {
			t.Fatal(err)
		}
	}
	if err := zw.Close(); err != nil {
		t.Fatal(err)
	}
	return buf.Bytes()
}
func TestKeyFormatsAndGitHubArtifact(t *testing.T) {
	priv, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	pkcs8, err := x509.MarshalPKCS8PrivateKey(priv)
	if err != nil {
		t.Fatal(err)
	}
	pem8 := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: pkcs8})
	pem1 := pem.EncodeToMemory(&pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(priv)})
	enc, err := encryptPrivateKeyPEM(pem8, "some very good passphrase 123!")
	if err != nil {
		t.Fatalf("encrypt PEM: %v", err)
	}
	for _, tc := range []struct {
		name             string
		bytes            []byte
		format, password string
	}{
		{"pkcs8", pem8, "pkcs8", ""}, {"pkcs1", pem1, "pkcs1", ""}, {"encrypted", enc, "encrypted", "some very good passphrase 123!"},
		{"autodetect", enc, "auto", "some very good passphrase 123!"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, _, err := parseRSAKey(tc.bytes, tc.format, tc.password)
			if err != nil {
				t.Fatal(err)
			}
			if got.N.Cmp(priv.N) != 0 {
				t.Fatal("private key changed")
			}
		})
	}
	if _, _, err := parseRSAKey(enc, "auto", "wrong-password"); err == nil {
		t.Fatal("incorrect password accepted")
	}
	if _, _, err := parseRSAKey(pem8, "pkcs1", ""); err == nil {
		t.Fatal("incorrect type selection accepted")
	}
	apk := makeZIP(t, map[string][]byte{"AndroidManifest.xml": {1, 2, 3}, "classes.dex": {4, 5, 6}, "resources.arsc": {1}})
	apkHash := sha256.Sum256(apk)
	filename := "Charming.MediaLab.test.apk"
	inner := makeZIP(t, map[string][]byte{
		"artifacts/" + filename:    apk,
		"artifacts/SHA256SUMS.txt": []byte(hex.EncodeToString(apkHash[:]) + "  artifacts/" + filename + "\n"),
	})
	pubDER, err := x509.MarshalPKIXPublicKey(&priv.PublicKey)
	if err != nil {
		t.Fatal(err)
	}
	id := sha256.Sum256(pubDER)
	aesKey := make([]byte, 32)
	iv := make([]byte, 12)
	rand.Read(aesKey)
	rand.Read(iv)
	wrapped, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, &priv.PublicKey, aesKey, nil)
	if err != nil {
		t.Fatal(err)
	}
	aad := aadEnvelope{1, "AES-256-GCM", "RSA-OAEP-SHA256", hex.EncodeToString(id[:]), base64.StdEncoding.EncodeToString(wrapped), base64.StdEncoding.EncodeToString(iv)}
	aadData, _ := json.Marshal(aad)
	block, _ := aes.NewCipher(aesKey)
	gcm, _ := cipher.NewGCM(block)
	sealed := gcm.Seal(nil, iv, inner, aadData)
	meta := envelope{aad.Version, aad.Algorithm, aad.KeyAlgorithm, aad.Recipient, aad.WrappedKey, aad.IV, base64.StdEncoding.EncodeToString(sealed[len(sealed)-16:])}
	jsonMeta, _ := json.MarshalIndent(meta, "", "  ")
	outer := makeZIP(t, map[string][]byte{"sideload.zip.enc": sealed[:len(sealed)-16], "sideload.zip.enc.json": jsonMeta})
	temp := t.TempDir()
	archive := filepath.Join(temp, "artifact.zip")
	keyPath := filepath.Join(temp, "rsa.pem")
	output := filepath.Join(temp, "output.apk")
	os.WriteFile(archive, outer, 0600)
	os.WriteFile(keyPath, enc, 0600)
	digest, err := decryptGitHubArtifact(archive, keyPath, "some very good passphrase 123!", "auto", output)
	if err != nil {
		t.Fatal(err)
	}
	if digest != hex.EncodeToString(apkHash[:]) {
		t.Fatal("wrong checksum")
	}
	extracted, err := os.ReadFile(output)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(apk, extracted) {
		t.Fatal("APK content changed")
	}
	_, err = decryptGitHubArtifact(archive, keyPath, "some very good passphrase 123!", "auto", output)
	if err == nil || !strings.Contains(err.Error(), "already exists") {
		t.Fatalf("existing output overwritten: %v", err)
	}
	keyPath2 := filepath.Join(temp, "wrong.pem")
	other, _ := rsa.GenerateKey(rand.Reader, 2048)
	os.WriteFile(keyPath2, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: mustDER(t, other)}), 0600)
	_, err = decryptGitHubArtifact(archive, keyPath2, "", "auto", filepath.Join(temp, "wrong.apk"))
	if err == nil || !strings.Contains(err.Error(), "does not match") {
		t.Fatalf("wrong key accepted or unexpected error: %v", err)
	}
}
func mustDER(t *testing.T, k *rsa.PrivateKey) []byte {
	t.Helper()
	d, e := x509.MarshalPKCS8PrivateKey(k)
	if e != nil {
		t.Fatal(e)
	}
	return d
}
