module charmingmedialab/apkdecryptor

go 1.23
