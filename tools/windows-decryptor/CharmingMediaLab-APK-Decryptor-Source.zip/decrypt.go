package main

import (
	"archive/zip"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"crypto/x509"
	"encoding/asn1"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"hash"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const maxKeyBytes = 2 * 1024 * 1024
const maxJSONBytes = 64 * 1024
const maxEncryptedBytes = 2 * 1024 * 1024 * 1024 // refuse unexpectedly huge input
const maxAPKBytes = 2 * 1024 * 1024 * 1024

var (
	oidPBES2      = asn1.ObjectIdentifier{1, 2, 840, 113549, 1, 5, 13}
	oidPBKDF2     = asn1.ObjectIdentifier{1, 2, 840, 113549, 1, 5, 12}
	oidHmacSHA1   = asn1.ObjectIdentifier{1, 2, 840, 113549, 2, 7}
	oidHmacSHA256 = asn1.ObjectIdentifier{1, 2, 840, 113549, 2, 9}
	oidHmacSHA384 = asn1.ObjectIdentifier{1, 2, 840, 113549, 2, 10}
	oidHmacSHA512 = asn1.ObjectIdentifier{1, 2, 840, 113549, 2, 11}
	oidAES128CBC  = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 1, 2}
	oidAES192CBC  = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 1, 22}
	oidAES256CBC  = asn1.ObjectIdentifier{2, 16, 840, 1, 101, 3, 4, 1, 42}
)

type algorithmID struct {
	Algorithm  asn1.ObjectIdentifier
	Parameters asn1.RawValue `asn1:"optional"`
}
type pbes2Info struct {
	KDF        algorithmID
	Encryption algorithmID
}
type pbkdf2Info struct {
	Salt       []byte
	Iterations int
	KeyLength  int         `asn1:"optional"`
	PRF        algorithmID `asn1:"optional"`
}
type encryptedPKCS8Info struct {
	Algorithm     algorithmID
	EncryptedData []byte
}

type envelope struct {
	Version      int    `json:"version"`
	Algorithm    string `json:"algorithm"`
	KeyAlgorithm string `json:"keyAlgorithm"`
	Recipient    string `json:"recipient"`
	WrappedKey   string `json:"wrappedKey"`
	IV           string `json:"iv"`
	Tag          string `json:"tag"`
}
type aadEnvelope struct {
	Version      int    `json:"version"`
	Algorithm    string `json:"algorithm"`
	KeyAlgorithm string `json:"keyAlgorithm"`
	Recipient    string `json:"recipient"`
	WrappedKey   string `json:"wrappedKey"`
	IV           string `json:"iv"`
}

func checkASN1Trailing(rest []byte) error {
	if len(rest) != 0 {
		return errors.New("unexpected trailing ASN.1 data")
	}
	return nil
}
func parseRSAKey(data []byte, format string, password string) (*rsa.PrivateKey, string, error) {
	if len(data) > maxKeyBytes {
		return nil, "", errors.New("private key file is unexpectedly large")
	}
	block, rest := pem.Decode(bytes.TrimSpace(data))
	if block == nil || len(bytes.TrimSpace(rest)) != 0 {
		return nil, "", errors.New("not a single valid PEM private-key block")
	}
	var detected string
	switch block.Type {
	case "PRIVATE KEY":
		detected = "pkcs8"
	case "RSA PRIVATE KEY":
		detected = "pkcs1"
	case "ENCRYPTED PRIVATE KEY":
		detected = "encrypted"
	default:
		return nil, "", fmt.Errorf("unsupported PEM header: %s", block.Type)
	}
	if format != "auto" && format != detected {
		return nil, "", fmt.Errorf("selected key type does not match file header (%s)", block.Type)
	}
	var value any
	var err error
	switch detected {
	case "pkcs8":
		value, err = x509.ParsePKCS8PrivateKey(block.Bytes)
	case "pkcs1":
		var k *rsa.PrivateKey
		k, err = x509.ParsePKCS1PrivateKey(block.Bytes)
		value = k
	case "encrypted":
		if password == "" {
			return nil, "", errors.New("this encrypted private key requires its password")
		}
		var plaintext []byte
		plaintext, err = decryptEncryptedPKCS8(block.Bytes, password)
		if err == nil {
			value, err = x509.ParsePKCS8PrivateKey(plaintext)
		}
		for i := range plaintext {
			plaintext[i] = 0
		}
	}
	if err != nil {
		return nil, "", fmt.Errorf("cannot read private key: %w", err)
	}
	key, ok := value.(*rsa.PrivateKey)
	if !ok {
		return nil, "", errors.New("the private key is not RSA; this GitHub artifact requires an RSA key")
	}
	if err := key.Validate(); err != nil {
		return nil, "", fmt.Errorf("invalid RSA key: %w", err)
	}
	return key, detected, nil
}

func pbkdf2(password, salt []byte, iterations, keyLen int, newHash func() hash.Hash) ([]byte, error) {
	if iterations < 1000 || iterations > 10000000 {
		return nil, errors.New("unsupported PBKDF2 iteration count")
	}
	if keyLen <= 0 || keyLen > 128 {
		return nil, errors.New("unsupported derived key length")
	}
	h := hmac.New(newHash, password)
	out := make([]byte, 0, keyLen)
	for block := 1; len(out) < keyLen; block++ {
		index := []byte{byte(block >> 24), byte(block >> 16), byte(block >> 8), byte(block)}
		h.Reset()
		h.Write(salt)
		h.Write(index)
		u := h.Sum(nil)
		t := append([]byte(nil), u...)
		for j := 1; j < iterations; j++ {
			h.Reset()
			h.Write(u)
			u = h.Sum(u[:0])
			for k := range t {
				t[k] ^= u[k]
			}
		}
		out = append(out, t...)
	}
	return out[:keyLen], nil
}
func getPRF(oid asn1.ObjectIdentifier) (func() hash.Hash, error) {
	switch {
	case oid.Equal(oidHmacSHA1):
		return sha1.New, nil
	case oid.Equal(oidHmacSHA256):
		return sha256.New, nil
	case oid.Equal(oidHmacSHA384):
		return sha512.New384, nil
	case oid.Equal(oidHmacSHA512):
		return sha512.New, nil
	default:
		return nil, errors.New("unsupported PBKDF2 PRF; use OpenSSL PBES2/PBKDF2 with HMAC-SHA256")
	}
}
func cbcKeyLen(oid asn1.ObjectIdentifier) (int, error) {
	switch {
	case oid.Equal(oidAES128CBC):
		return 16, nil
	case oid.Equal(oidAES192CBC):
		return 24, nil
	case oid.Equal(oidAES256CBC):
		return 32, nil
	default:
		return 0, errors.New("unsupported PEM encryption: use PBES2 with AES-256-CBC")
	}
}
func decryptEncryptedPKCS8(der []byte, pass string) ([]byte, error) {
	var info encryptedPKCS8Info
	rest, err := asn1.Unmarshal(der, &info)
	if err != nil || checkASN1Trailing(rest) != nil {
		return nil, errors.New("invalid encrypted PKCS#8 envelope")
	}
	if !info.Algorithm.Algorithm.Equal(oidPBES2) {
		return nil, errors.New("unsupported encrypted PEM algorithm: expected PBES2")
	}
	var params pbes2Info
	rest, err = asn1.Unmarshal(info.Algorithm.Parameters.FullBytes, &params)
	if err != nil || checkASN1Trailing(rest) != nil {
		return nil, errors.New("invalid PBES2 settings")
	}
	if !params.KDF.Algorithm.Equal(oidPBKDF2) {
		return nil, errors.New("unsupported key derivation: expected PBKDF2")
	}
	var kdf pbkdf2Info
	rest, err = asn1.Unmarshal(params.KDF.Parameters.FullBytes, &kdf)
	if err != nil || checkASN1Trailing(rest) != nil {
		return nil, errors.New("invalid PBKDF2 parameters")
	}
	if len(kdf.Salt) < 8 || len(kdf.Salt) > 128 {
		return nil, errors.New("unsupported PBKDF2 salt")
	}
	length, err := cbcKeyLen(params.Encryption.Algorithm)
	if err != nil {
		return nil, err
	}
	if kdf.KeyLength != 0 && kdf.KeyLength != length {
		return nil, errors.New("incorrect PBKDF2 key length")
	}
	prfOID := kdf.PRF.Algorithm
	if len(prfOID) == 0 {
		prfOID = oidHmacSHA1
	} // PBKDF2 default
	newHash, err := getPRF(prfOID)
	if err != nil {
		return nil, err
	}
	var iv []byte
	rest, err = asn1.Unmarshal(params.Encryption.Parameters.FullBytes, &iv)
	if err != nil || checkASN1Trailing(rest) != nil || len(iv) != aes.BlockSize {
		return nil, errors.New("invalid AES-CBC IV")
	}
	if len(info.EncryptedData) == 0 || len(info.EncryptedData)%aes.BlockSize != 0 {
		return nil, errors.New("invalid AES-CBC ciphertext")
	}
	key, err := pbkdf2([]byte(pass), kdf.Salt, kdf.Iterations, length, newHash)
	if err != nil {
		return nil, err
	}
	defer func() {
		for i := range key {
			key[i] = 0
		}
	}()
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	plaintext := make([]byte, len(info.EncryptedData))
	cipher.NewCBCDecrypter(block, iv).CryptBlocks(plaintext, info.EncryptedData)
	pad := int(plaintext[len(plaintext)-1])
	valid := pad > 0 && pad <= aes.BlockSize
	if valid {
		for _, b := range plaintext[len(plaintext)-pad:] {
			if int(b) != pad {
				valid = false
			}
		}
	}
	if !valid {
		return nil, errors.New("incorrect PEM password or corrupted encrypted key")
	}
	return plaintext[:len(plaintext)-pad], nil
}

func encryptPrivateKeyPEM(in []byte, password string) ([]byte, error) {
	if len(password) < 12 {
		return nil, errors.New("choose a password of at least 12 characters")
	}
	key, _, err := parseRSAKey(in, "auto", "")
	if err != nil {
		return nil, fmt.Errorf("select an unencrypted RSA PEM: %w", err)
	}
	der, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return nil, err
	}
	salt := make([]byte, 16)
	iv := make([]byte, 16)
	if _, err = rand.Read(salt); err != nil {
		return nil, err
	}
	if _, err = rand.Read(iv); err != nil {
		return nil, err
	}
	const iterations = 200000
	keyBytes, err := pbkdf2([]byte(password), salt, iterations, 32, sha256.New)
	if err != nil {
		return nil, err
	}
	defer func() {
		for i := range keyBytes {
			keyBytes[i] = 0
		}
	}()
	block, err := aes.NewCipher(keyBytes)
	if err != nil {
		return nil, err
	}
	padding := aes.BlockSize - len(der)%aes.BlockSize
	padded := append(append([]byte(nil), der...), bytes.Repeat([]byte{byte(padding)}, padding)...)
	ciphertext := make([]byte, len(padded))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(ciphertext, padded)
	nullDER, _ := asn1.Marshal(asn1.RawValue{Tag: asn1.TagNull})
	prf := algorithmID{Algorithm: oidHmacSHA256, Parameters: asn1.RawValue{FullBytes: nullDER}}
	kdfDER, err := asn1.Marshal(pbkdf2Info{Salt: salt, Iterations: iterations, PRF: prf})
	if err != nil {
		return nil, err
	}
	ivDER, err := asn1.Marshal(iv)
	if err != nil {
		return nil, err
	}
	pbes2DER, err := asn1.Marshal(pbes2Info{
		KDF:        algorithmID{Algorithm: oidPBKDF2, Parameters: asn1.RawValue{FullBytes: kdfDER}},
		Encryption: algorithmID{Algorithm: oidAES256CBC, Parameters: asn1.RawValue{FullBytes: ivDER}},
	})
	if err != nil {
		return nil, err
	}
	finalDER, err := asn1.Marshal(encryptedPKCS8Info{
		Algorithm:     algorithmID{Algorithm: oidPBES2, Parameters: asn1.RawValue{FullBytes: pbes2DER}},
		EncryptedData: ciphertext,
	})
	if err != nil {
		return nil, err
	}
	return pem.EncodeToMemory(&pem.Block{Type: "ENCRYPTED PRIVATE KEY", Bytes: finalDER}), nil
}

func archiveItem(r *zip.Reader, want string) (*zip.File, error) {
	var f *zip.File
	for _, v := range r.File {
		if v.Name == want || strings.TrimPrefix(v.Name, "protected-artifacts/") == want || strings.TrimPrefix(v.Name, "frontend/protected-artifacts/") == want {
			if f != nil {
				return nil, fmt.Errorf("duplicate file in artifact: %s", want)
			}
			f = v
		}
	}
	if f == nil {
		return nil, fmt.Errorf("artifact missing %s", want)
	}
	return f, nil
}
func readZipEntry(f *zip.File, limit uint64) ([]byte, error) {
	if f.UncompressedSize64 > limit {
		return nil, errors.New("artifact file too large")
	}
	r, err := f.Open()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	data, err := io.ReadAll(io.LimitReader(r, int64(limit)+1))
	if err != nil {
		return nil, err
	}
	if uint64(len(data)) > limit {
		return nil, errors.New("artifact file exceeds size limit")
	}
	return data, nil
}
func parseEnvelope(data []byte) (envelope, error) {
	var meta envelope
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if err := d.Decode(&meta); err != nil {
		return meta, fmt.Errorf("invalid artifact metadata: %w", err)
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return meta, errors.New("metadata has trailing information")
	}
	if meta.Version != 1 || meta.Algorithm != "AES-256-GCM" || meta.KeyAlgorithm != "RSA-OAEP-SHA256" {
		return meta, errors.New("unsupported GitHub artifact encryption version")
	}
	return meta, nil
}
func decryptPayload(ciphertext []byte, meta envelope, key *rsa.PrivateKey) ([]byte, error) {
	pubDER, err := x509.MarshalPKIXPublicKey(&key.PublicKey)
	if err != nil {
		return nil, err
	}
	hash := sha256.Sum256(pubDER)
	if hex.EncodeToString(hash[:]) != meta.Recipient {
		return nil, errors.New("this private key does not match the public key used by this GitHub build")
	}
	wrapped, err := base64.StdEncoding.DecodeString(meta.WrappedKey)
	if err != nil {
		return nil, errors.New("invalid wrapped key encoding")
	}
	sessionKey, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, key, wrapped, nil)
	if err != nil {
		return nil, fmt.Errorf("RSA key unwrap failed: %w", err)
	}
	defer func() {
		for i := range sessionKey {
			sessionKey[i] = 0
		}
	}()
	if len(sessionKey) != 32 {
		return nil, errors.New("invalid AES session key size")
	}
	iv, err := base64.StdEncoding.DecodeString(meta.IV)
	if err != nil || len(iv) != 12 {
		return nil, errors.New("invalid AES-GCM IV")
	}
	tag, err := base64.StdEncoding.DecodeString(meta.Tag)
	if err != nil || len(tag) != 16 {
		return nil, errors.New("invalid AES-GCM authentication tag")
	}
	aad, err := json.Marshal(aadEnvelope{meta.Version, meta.Algorithm, meta.KeyAlgorithm, meta.Recipient, meta.WrappedKey, meta.IV})
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(sessionKey)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	payload := make([]byte, len(ciphertext)+len(tag))
	copy(payload, ciphertext)
	copy(payload[len(ciphertext):], tag)
	plaintext, err := gcm.Open(nil, iv, payload, aad)
	if err != nil {
		return nil, errors.New("authentication failed: encrypted artifact or metadata is corrupted")
	}
	return plaintext, nil
}
func extractAPKFromZip(z *zip.Reader, output string) (string, error) {
	var apk *zip.File
	var checksum *zip.File
	for _, f := range z.File {
		if strings.HasSuffix(strings.ToLower(f.Name), ".apk") && !f.FileInfo().IsDir() {
			if apk != nil {
				return "", errors.New("more than one APK found; artifact is ambiguous")
			}
			apk = f
		}
		if filepath.Base(f.Name) == "SHA256SUMS.txt" {
			checksum = f
		}
	}
	if apk == nil {
		return "", errors.New("no APK found inside decrypted archive")
	}
	if apk.UncompressedSize64 > maxAPKBytes {
		return "", errors.New("APK is unexpectedly large")
	}
	if filepath.Ext(strings.ToLower(output)) != ".apk" {
		return "", errors.New("output filename must end with .apk")
	}
	if _, err := os.Stat(output); err == nil {
		return "", errors.New("output APK already exists; choose a different filename")
	}
	dir := filepath.Dir(output)
	temp, err := os.CreateTemp(dir, ".charming-apk-*.partial")
	if err != nil {
		return "", err
	}
	tmpName := temp.Name()
	defer os.Remove(tmpName)
	r, err := apk.Open()
	if err != nil {
		temp.Close()
		return "", err
	}
	h := sha256.New()
	_, err = io.Copy(io.MultiWriter(temp, h), io.LimitReader(r, maxAPKBytes+1))
	r.Close()
	closeErr := temp.Close()
	if err != nil {
		return "", err
	}
	if closeErr != nil {
		return "", closeErr
	}
	if checksum != nil {
		d, err := readZipEntry(checksum, 64*1024)
		if err != nil {
			return "", err
		}
		wanted := hex.EncodeToString(h.Sum(nil))
		found := false
		for _, line := range strings.Split(string(d), "\n") {
			fields := strings.Fields(line)
			if len(fields) >= 2 && filepath.Base(strings.TrimPrefix(fields[1], "*")) == filepath.Base(apk.Name) {
				if !strings.EqualFold(fields[0], wanted) {
					return "", errors.New("APK SHA-256 checksum does not match build report")
				}
				found = true
			}
		}
		if !found {
			return "", errors.New("cannot locate APK hash in SHA256SUMS.txt")
		}
	}
	if err = validateAPK(tmpName); err != nil {
		return "", err
	}
	// Exclusive create ensures output cannot accidentally overwrite another build.
	to, err := os.OpenFile(output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return "", err
	}
	from, err := os.Open(tmpName)
	if err != nil {
		to.Close()
		os.Remove(output)
		return "", err
	}
	_, err = io.Copy(to, from)
	from.Close()
	closeErr = to.Close()
	if err != nil || closeErr != nil {
		os.Remove(output)
		if err != nil {
			return "", err
		}
		return "", closeErr
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}
func validateAPK(path string) error {
	z, err := zip.OpenReader(path)
	if err != nil {
		return fmt.Errorf("APK is not a valid ZIP package: %w", err)
	}
	defer z.Close()
	manifest := false
	dex := false
	for _, f := range z.File {
		if f.Name == "AndroidManifest.xml" {
			manifest = true
		}
		if f.Name == "classes.dex" {
			dex = true
		}
	}
	if !manifest {
		return errors.New("APK missing AndroidManifest.xml")
	}
	if !dex {
		return errors.New("APK missing classes.dex")
	}
	return nil
}
func decryptGitHubArtifact(zipPath, keyPath, password, format, output string) (string, error) {
	outer, err := zip.OpenReader(zipPath)
	if err != nil {
		return "", fmt.Errorf("not a GitHub ZIP download: %w", err)
	}
	defer outer.Close()
	encFile, err := archiveItem(&outer.Reader, "sideload.zip.enc")
	if err != nil {
		// Some older GitHub builds may contain a directly extractable signed APK.
		foundAPK := false
		for _, v := range outer.File {
			if strings.HasSuffix(strings.ToLower(v.Name), ".apk") {
				foundAPK = true
				break
			}
		}
		if foundAPK {
			return extractAPKFromZip(&outer.Reader, output)
		}
		return "", err
	}
	metaFile, err := archiveItem(&outer.Reader, "sideload.zip.enc.json")
	if err != nil {
		return "", err
	}
	data, err := readZipEntry(metaFile, maxJSONBytes)
	if err != nil {
		return "", err
	}
	meta, err := parseEnvelope(data)
	if err != nil {
		return "", err
	}
	pemData, err := os.ReadFile(keyPath)
	if err != nil {
		return "", fmt.Errorf("cannot open PEM file: %w", err)
	}
	privateKey, _, err := parseRSAKey(pemData, format, password)
	if err != nil {
		return "", err
	}
	ciphertext, err := readZipEntry(encFile, maxEncryptedBytes)
	if err != nil {
		return "", err
	}
	plaintext, err := decryptPayload(ciphertext, meta, privateKey)
	if err != nil {
		return "", err
	}
	inner, err := zip.NewReader(bytes.NewReader(plaintext), int64(len(plaintext)))
	if err != nil {
		return "", fmt.Errorf("decrypted content is not a ZIP archive: %w", err)
	}
	return extractAPKFromZip(inner, output)
}
func protectPEM(input, output, password string) error {
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	encrypted, err := encryptPrivateKeyPEM(data, password)
	if err != nil {
		return err
	}
	f, err := os.OpenFile(output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	_, err = f.Write(encrypted)
	closeErr := f.Close()
	if err != nil || closeErr != nil {
		os.Remove(output)
		if err != nil {
			return err
		}
		return closeErr
	}
	return nil
}
